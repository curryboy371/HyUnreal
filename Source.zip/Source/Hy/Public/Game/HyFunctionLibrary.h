// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "HyFunctionLibrary.generated.h"

/**
 * 
 */
UCLASS()
class HY_API UHyFunctionLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
};
