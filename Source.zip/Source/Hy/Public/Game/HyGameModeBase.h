// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "HyGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class HY_API AHyGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
public:

	void Temp()
	{

	}
};
